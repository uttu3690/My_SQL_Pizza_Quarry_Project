-- Retrieve the total number of orders placed.
select count(order_id) as total_id from orders;