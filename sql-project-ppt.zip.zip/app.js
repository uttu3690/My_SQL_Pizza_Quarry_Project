// SQL Database Project Presentation App
class PresentationApp {
    constructor() {
        this.currentSlide = 0;
        this.slides = [
            {
                id: 1,
                title: "SQL Database Project",
                type: "title",
                content: {
                    subtitle: "Utilizing SQL Queries for Database Problem Solving",
                    presenter: "Database Developer",
                    date: "September 2024"
                }
            },
            {
                id: 2,
                title: "Project Overview",
                type: "content",
                content: {
                    points: [
                        "Demonstrated practical application of SQL queries",
                        "Solved complex database-related problems",
                        "Applied various SQL operations and techniques",
                        "Focused on data retrieval, analysis, and optimization"
                    ]
                }
            },
            {
                id: 3,
                title: "Database Structure",
                type: "content",
                content: {
                    points: [
                        "Designed normalized database schema",
                        "Implemented multiple related tables",
                        "Established primary and foreign key relationships",
                        "Ensured data integrity and consistency"
                    ]
                }
            },
            {
                id: 4,
                title: "SQL Queries Implemented",
                type: "content",
                content: {
                    points: [
                        "SELECT statements for data retrieval",
                        "JOIN operations (INNER, LEFT, RIGHT, FULL)",
                        "Aggregate functions (COUNT, SUM, AVG, MAX, MIN)",
                        "WHERE clauses for data filtering",
                        "GROUP BY and ORDER BY operations",
                        "Subqueries and nested queries",
                        "CREATE, INSERT, UPDATE, DELETE operations"
                    ]
                }
            },
            {
                id: 5,
                title: "Key Query Examples",
                type: "code",
                content: {
                    examples: [
                        {
                            title: "Customer Data Retrieval",
                            query: "SELECT c.customer_name, COUNT(o.order_id) as total_orders\nFROM customers c\nJOIN orders o ON c.customer_id = o.customer_id\nWHERE o.order_date >= '2024-01-01'\nGROUP BY c.customer_id\nORDER BY total_orders DESC;",
                            description: "Retrieves customer names with their total order count from 2024"
                        },
                        {
                            title: "Revenue Analysis",
                            query: "SELECT p.product_category,\n       SUM(od.quantity * od.unit_price) as revenue\nFROM products p\nJOIN order_details od ON p.product_id = od.product_id\nGROUP BY p.product_category\nHAVING revenue > 10000;",
                            description: "Calculates revenue by product category with minimum threshold"
                        }
                    ]
                }
            },
            {
                id: 6,
                title: "Results and Analysis",
                type: "content",
                content: {
                    points: [
                        "Successfully retrieved and analyzed large datasets",
                        "Identified key business insights through data queries",
                        "Optimized query performance using indexes",
                        "Generated meaningful reports for decision-making"
                    ]
                }
            },
            {
                id: 7,
                title: "Challenges and Solutions",
                type: "content",
                content: {
                    points: [
                        "Challenge: Complex multi-table joins",
                        "Solution: Implemented step-by-step query building",
                        "Challenge: Query performance issues",
                        "Solution: Added appropriate indexes and optimized WHERE clauses",
                        "Challenge: Data consistency problems",
                        "Solution: Applied normalization and referential integrity"
                    ]
                }
            },
            {
                id: 8,
                title: "Technologies Used",
                type: "content",
                content: {
                    points: [
                        "SQL (Structured Query Language)",
                        "MySQL/PostgreSQL/SQL Server Database",
                        "Database Management Tools",
                        "Query optimization techniques",
                        "Data modeling and normalization"
                    ]
                }
            },
            {
                id: 9,
                title: "Key Learnings",
                type: "content",
                content: {
                    points: [
                        "Mastered complex SQL query construction",
                        "Understanding of database design principles",
                        "Query optimization and performance tuning",
                        "Data analysis and business intelligence skills",
                        "Problem-solving through structured data approach"
                    ]
                }
            },
            {
                id: 10,
                title: "Conclusion",
                type: "content",
                content: {
                    points: [
                        "Successfully demonstrated SQL proficiency",
                        "Solved real-world database problems",
                        "Developed scalable and efficient solutions",
                        "Ready to apply skills in professional environment",
                        "Future: Explore advanced SQL features and big data tools"
                    ]
                }
            }
        ];
        
        this.totalSlides = this.slides.length;
        this.init();
    }

    init() {
        this.renderSlides();
        this.renderDots();
        this.updateSlideCounter();
        this.bindEvents();
        this.showSlide(0);
    }

    renderSlides() {
        const container = document.getElementById('slidesContainer');
        container.innerHTML = '';

        this.slides.forEach((slide, index) => {
            const slideElement = document.createElement('div');
            slideElement.className = `slide slide--${slide.type}`;
            slideElement.id = `slide-${index}`;

            if (slide.type === 'title') {
                slideElement.innerHTML = this.renderTitleSlide(slide);
            } else if (slide.type === 'content') {
                slideElement.innerHTML = this.renderContentSlide(slide);
            } else if (slide.type === 'code') {
                slideElement.innerHTML = this.renderCodeSlide(slide);
            }

            container.appendChild(slideElement);
        });
    }

    renderTitleSlide(slide) {
        return `
            <h1>${slide.title}</h1>
            <div class="subtitle">${slide.content.subtitle}</div>
            <div class="meta-info">
                <span><strong>Presenter:</strong> ${slide.content.presenter}</span>
                <span><strong>Date:</strong> ${slide.content.date}</span>
            </div>
        `;
    }

    renderContentSlide(slide) {
        const points = slide.content.points.map(point => `<li>${point}</li>`).join('');
        return `
            <h2>${slide.title}</h2>
            <ul>${points}</ul>
        `;
    }

    renderCodeSlide(slide) {
        const examples = slide.content.examples.map(example => `
            <div class="code-example">
                <h4>${example.title}</h4>
                <div class="code-block">${this.highlightSQL(example.query)}</div>
                <div class="code-description">${example.description}</div>
            </div>
        `).join('');
        
        return `
            <h2>${slide.title}</h2>
            ${examples}
        `;
    }

    highlightSQL(query) {
        // Simple SQL syntax highlighting
        const keywords = ['SELECT', 'FROM', 'WHERE', 'JOIN', 'INNER', 'LEFT', 'RIGHT', 'FULL', 'ON', 'GROUP BY', 'ORDER BY', 'HAVING', 'COUNT', 'SUM', 'AVG', 'MAX', 'MIN', 'AS', 'DESC', 'ASC', 'AND', 'OR', 'NOT', 'IN', 'LIKE', 'BETWEEN', 'IS', 'NULL', 'CREATE', 'INSERT', 'UPDATE', 'DELETE', 'ALTER', 'DROP', 'INDEX', 'TABLE', 'DATABASE', 'DISTINCT', 'LIMIT', 'OFFSET', 'UNION', 'ALL'];
        
        let highlighted = query;
        
        // Highlight keywords
        keywords.forEach(keyword => {
            const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
            highlighted = highlighted.replace(regex, `<span class="sql-keyword">${keyword}</span>`);
        });
        
        // Highlight strings
        highlighted = highlighted.replace(/'([^']*)'/g, '<span class="sql-string">\'$1\'</span>');
        
        // Highlight numbers
        highlighted = highlighted.replace(/\b\d+\b/g, '<span class="sql-number">$&</span>');
        
        // Highlight comments
        highlighted = highlighted.replace(/--(.*)$/gm, '<span class="sql-comment">--$1</span>');
        
        return highlighted;
    }

    renderDots() {
        const dotsContainer = document.getElementById('slideDots');
        dotsContainer.innerHTML = '';

        for (let i = 0; i < this.totalSlides; i++) {
            const dot = document.createElement('span');
            dot.className = 'dot';
            dot.setAttribute('data-slide', i);
            dot.addEventListener('click', (e) => {
                e.preventDefault();
                const slideIndex = parseInt(e.target.getAttribute('data-slide'));
                this.goToSlide(slideIndex);
            });
            dotsContainer.appendChild(dot);
        }
    }

    bindEvents() {
        // Navigation buttons
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        
        if (prevBtn) {
            prevBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.previousSlide();
            });
        }
        
        if (nextBtn) {
            nextBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.nextSlide();
            });
        }

        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            switch(e.key) {
                case 'ArrowLeft':
                case 'ArrowUp':
                    e.preventDefault();
                    this.previousSlide();
                    break;
                case 'ArrowRight':
                case 'ArrowDown':
                    e.preventDefault();
                    this.nextSlide();
                    break;
                case 'Home':
                    e.preventDefault();
                    this.goToSlide(0);
                    break;
                case 'End':
                    e.preventDefault();
                    this.goToSlide(this.totalSlides - 1);
                    break;
            }
        });

        // Touch/swipe support for mobile
        let startX = 0;
        let endX = 0;

        document.addEventListener('touchstart', (e) => {
            startX = e.touches[0].clientX;
        }, { passive: true });

        document.addEventListener('touchend', (e) => {
            endX = e.changedTouches[0].clientX;
            const diff = startX - endX;

            if (Math.abs(diff) > 50) { // Minimum swipe distance
                if (diff > 0) {
                    this.nextSlide();
                } else {
                    this.previousSlide();
                }
            }
        }, { passive: true });
    }

    showSlide(index) {
        // Hide all slides
        const allSlides = document.querySelectorAll('.slide');
        allSlides.forEach(slide => {
            slide.classList.remove('active');
        });

        // Show current slide
        const currentSlideElement = document.getElementById(`slide-${index}`);
        if (currentSlideElement) {
            currentSlideElement.classList.add('active');
        }

        // Update dots
        const allDots = document.querySelectorAll('.dot');
        allDots.forEach((dot, i) => {
            if (i === index) {
                dot.classList.add('active');
            } else {
                dot.classList.remove('active');
            }
        });

        // Update navigation buttons
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        
        if (prevBtn) {
            prevBtn.disabled = index === 0;
        }
        
        if (nextBtn) {
            nextBtn.disabled = index === this.totalSlides - 1;
        }

        // Update slide counter
        this.updateSlideCounter();
    }

    nextSlide() {
        if (this.currentSlide < this.totalSlides - 1) {
            this.currentSlide++;
            this.showSlide(this.currentSlide);
        }
    }

    previousSlide() {
        if (this.currentSlide > 0) {
            this.currentSlide--;
            this.showSlide(this.currentSlide);
        }
    }

    goToSlide(index) {
        if (index >= 0 && index < this.totalSlides) {
            this.currentSlide = index;
            this.showSlide(this.currentSlide);
        }
    }

    updateSlideCounter() {
        const currentSlideEl = document.getElementById('currentSlide');
        const totalSlidesEl = document.getElementById('totalSlides');
        
        if (currentSlideEl) {
            currentSlideEl.textContent = this.currentSlide + 1;
        }
        
        if (totalSlidesEl) {
            totalSlidesEl.textContent = this.totalSlides;
        }
    }
}

// Initialize the presentation when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new PresentationApp();
});

// Prevent context menu for a more app-like experience
document.addEventListener('contextmenu', (e) => {
    e.preventDefault();
});

// Handle window resize for responsive design
window.addEventListener('resize', () => {
    // Force recalculation of slide dimensions if needed
    const activeSlide = document.querySelector('.slide.active');
    if (activeSlide) {
        activeSlide.style.height = 'auto';
    }
});